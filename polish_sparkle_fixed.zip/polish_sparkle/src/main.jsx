import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import PolishSparkleHome from './PolishSparkleHome'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PolishSparkleHome />
  </React.StrictMode>,
)