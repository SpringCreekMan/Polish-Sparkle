// Polish Sparkle - React Website with Tailwind CSS and Integrations

import React, { useState } from "react";
// Import the hero image directly from the assets folder. When bundled with Vite, this
// will embed the image and return a URL that resolves correctly at runtime.
import heroImg from "./assets/polish-lady.png";

export default function PolishSparkleHome() {
  const calendlyLink = "https://calendly.com/polishsparkle/cleaning-booking";
  const [form, setForm] = useState({ name: "", email: "", phone: "", address: "" });
  const [showChat, setShowChat] = useState(false);

  const handleInputChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <main className="bg-white text-gray-900">
      {/* Navigation bar */}
      <header className="flex flex-col md:flex-row justify-between items-center py-4 px-6 max-w-6xl mx-auto">
        <div className="text-2xl font-bold">Polish Sparkle</div>
        <nav className="mt-4 md:mt-0 space-x-8 text-lg">
          <a href="#" className="hover:text-blue-500">Home</a>
          <a href="#about" className="hover:text-blue-500">About</a>
          <a href="#services" className="hover:text-blue-500">Services</a>
          <a href="#contact" className="hover:text-blue-500">Contact</a>
        </nav>
      </header>

      {/* Hero section */}
      <section className="grid md:grid-cols-2 gap-8 px-6 py-16 max-w-6xl mx-auto items-center">
        <div>
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Cleaning Services in Chicago</h1>
          <p className="text-xl mb-8">Professional house cleaning for the Chicago area.</p>
          <a href={calendlyLink} target="_blank" rel="noopener noreferrer">
            <button className="text-lg px-8 py-3 bg-blue-500 text-white rounded-full hover:bg-blue-600">Book Now</button>
          </a>
        </div>
        <img
          src={heroImg}
          alt="Professional cleaner"
          className="rounded-2xl shadow-xl w-full h-auto object-cover"
        />
      </section>

      {/* About */}
      <section id="about" className="px-6 py-12 max-w-6xl mx-auto">
        <h2 className="text-3xl font-semibold mb-4">About Us</h2>
        <p>
          Polish Sparkle is a family-run cleaning service with Polish roots, serving the entire Chicago area. We combine traditional European work ethic with modern convenience. Our professional team delivers spotless homes and offices—every time.
        </p>
      </section>

      {/* Services */}
      <section id="services" className="bg-gray-100 py-12 px-6">
        <h2 className="text-3xl text-center font-semibold mb-10">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {[
            { title: "Standard Cleaning", desc: "Perfect for weekly or bi-weekly maintenance." },
            { title: "Deep Cleaning", desc: "A top-to-bottom clean of your entire space." },
            { title: "Move In/Out", desc: "Make sure your new home or old apartment sparkles." },
            { title: "Office Cleaning", desc: "Keep your workspace tidy and professional." },
            { title: "Post-Construction", desc: "Remove dust and debris after renovations." },
            { title: "Custom Plans", desc: "Tell us your needs—we’ll handle the mess." },
          ].map((service, idx) => (
            <div key={idx} className="rounded-2xl shadow-md bg-white p-6">
              <h3 className="text-xl font-bold mb-2">{service.title}</h3>
              <p>{service.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Booking */}
      <section className="py-12 px-6 max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-semibold mb-6">Book Your Cleaning</h2>
        <iframe
          src={calendlyLink}
          width="100%"
          height="700"
          frameBorder="0"
          className="rounded-xl shadow-xl"
        ></iframe>
      </section>

      {/* Testimonials */}
      <section className="bg-gray-100 py-12 px-6">
        <h2 className="text-3xl text-center font-semibold mb-8">What Clients Say</h2>
        <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          <blockquote className="p-6 bg-white rounded-xl shadow">
            “Absolutely the best cleaning crew I’ve used in Chicago. Punctual, polite, and very thorough.”
            <footer className="mt-4 text-right text-sm font-semibold">— Anna K., Wicker Park</footer>
          </blockquote>
          <blockquote className="p-6 bg-white rounded-xl shadow">
            “Polish Sparkle made my move-out cleanup stress-free. Highly recommend!”
            <footer className="mt-4 text-right text-sm font-semibold">— Mark D., Lincoln Park</footer>
          </blockquote>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-12 px-6 max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-semibold mb-4">Contact Us</h2>
        <p className="mb-2">Phone: (312) 555-2025</p>
        <p className="mb-2">Email: hello@polishsparkle.com</p>
        <p>Serving Chicago & Surrounding Suburbs</p>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6 text-center">
        <p>&copy; {new Date().getFullYear()} Polish Sparkle. All rights reserved.</p>
      </footer>

      {/* Chatbot */}
      <div className="fixed bottom-4 right-4">
        <button
          className="rounded-full shadow-xl bg-blue-500 text-white px-4 py-2 hover:bg-blue-600"
          onClick={() => setShowChat(!showChat)}
        >
          💬 Chat
        </button>
        {showChat && (
          <div className="mt-2 w-80 h-96 bg-white border rounded-2xl shadow-xl p-4 overflow-auto">
            <iframe
              src="https://polishsparkle-chatbot.vercel.app"
              width="100%"
              height="100%"
              title="AI Chatbot"
            ></iframe>
          </div>
        )}
      </div>
    </main>
  );
}